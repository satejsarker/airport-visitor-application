from django.contrib import admin

# Register your models here.
from flight.models import flight
admin.site.register(flight)