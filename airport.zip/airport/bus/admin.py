from django.contrib import admin

# Register your models here.
from bus.models import bus
admin.site.register(bus)