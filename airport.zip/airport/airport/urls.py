from django.conf.urls import url, include
from django.contrib import admin

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^' , include('personal.urls')),
url(r'^flight/' , include('flight.urls')),
url(r'^' , include('flight.urls')),
url(r'^shop/' , include('shop.urls')),
url(r'^bus/' , include('bus.urls')),
url(r'^arival/' , include('arival.urls')),
]