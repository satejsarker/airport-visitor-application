from django.contrib import admin

# Register your models here.
from arival.models import arival
admin.site.register(arival)