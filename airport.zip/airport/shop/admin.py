from django.contrib import admin

# Register your models here.
from shop.models import shop
admin.site.register(shop)